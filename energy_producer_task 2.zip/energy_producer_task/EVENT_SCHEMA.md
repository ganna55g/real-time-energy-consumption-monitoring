# Event schema

| Field | Type | Meaning |
|---|---|---|
| event_id | string | Unique event identifier |
| timestamp | ISO-8601 string | Event time |
| device_id | string | Stable device identifier |
| device_type | string | refrigerator, air_conditioner, washing_machine, lighting, solar_panel |
| metric_type | string | consumption or generation |
| power_w | number | Average power in watts |
| voltage_v | number | Voltage in volts |
| current_a | number | Current in amperes |
| energy_wh | number | Energy for the 10-minute interval in Wh |
| location | string | Site identifier |
| source | string | Dataset or simulation source |


## Raw dataset quality
The input CSV is intentionally uncleaned. Do not describe it as a cleaned or validated
dataset. Missing/invalid values, duplicates, malformed timestamps, and outliers are
included so a later cleaning/validation stage can be demonstrated.
