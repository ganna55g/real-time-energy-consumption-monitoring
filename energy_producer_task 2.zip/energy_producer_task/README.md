# Real-Time Energy Data Producer (Task 3)

## Goal
Read energy measurements from a CSV dataset, simulate individual electrical devices
and solar generation, then publish JSON events to the Kafka topic `energy-raw`.

## Project files
- `producer.py` — converts each CSV row into device-level events and publishes them.
- `data/energy_uncleaned.csv` — intentionally uncleaned raw dataset for testing data-quality handling.
- `requirements.txt` — Python dependency.

## Event format
Each Kafka message is one JSON event. Example:

```json
{
  "event_id": "unique-id",
  "timestamp": "2026-11-01T12:00:00+00:00",
  "device_id": "fridge-01",
  "device_type": "refrigerator",
  "metric_type": "consumption",
  "power_w": 850.4,
  "voltage_v": 230.1,
  "current_a": 3.696,
  "energy_wh": 141.733,
  "outdoor_temp_c": 24.5,
  "location": "home-01",
  "source": "uci_or_demo_dataset",
  "row_number": 1
}
```

Solar messages use `metric_type: "generation"` and `device_type: "solar_panel"`.
This distinction lets downstream Spark jobs separate consumption from renewable generation.

## 1. Requirements
- Python 3.9+
- A running Kafka broker reachable at `localhost:9092`
- Kafka topic named `energy-raw`

The Kafka broker and topic are expected to be provided by the infrastructure task.
Create the topic if it does not already exist, using your Kafka environment's topic tool.

## 2. Install Python dependency
From this folder:

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

macOS/Linux:
```bash
source .venv/bin/activate
```

Then:
```bash
pip install -r requirements.txt
```

## 3. Test the data transformation without Kafka
```bash
python producer.py --dry-run
```
This prints the JSON events that would be sent.

## 4. Send events to Kafka
```bash
python producer.py --broker localhost:9092 --topic energy-raw --interval 2 --loop
```
- `--interval 2`: wait two seconds after each source row.
- `--loop`: replay the CSV continuously to simulate a live stream.
- Stop with `Ctrl+C`.

## 5. Verify messages
With Kafka's console consumer (command depends on your Kafka installation), read from
the topic `energy-raw`, for example:

```bash
kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic energy-raw --from-beginning
```

On Windows, the script may be named `kafka-console-consumer.bat`.

## 6. Use the UCI dataset
The code supports the UCI **Appliances Energy Prediction** CSV format:
- `date` — timestamp
- `Appliances` — appliance energy in Wh per 10-minute interval
- `lights` — lighting energy in Wh per 10-minute interval
- `T_out` — outdoor temperature (optional)

Download the dataset from the UCI Machine Learning Repository and pass its CSV path:

```bash
python producer.py --csv path/to/energydata_complete.csv --broker localhost:9092 --topic energy-raw --interval 2 --loop
```

The UCI dataset does not contain solar generation readings. The producer therefore simulates
solar output using an approximate daylight curve when `solar_irradiance_wm2` is absent.
The included `sample_energy.csv` is a demo dataset for testing; it is generated sample data,
not an original UCI download.

## Notes for integration
- Topic: `energy-raw`
- Message value: UTF-8 JSON
- Message key: `device_id`
- Consumption and solar production are distinguished by `metric_type`.
- `power_w`, `voltage_v`, `current_a`, and `energy_wh` are numeric fields.
- The producer sends four consumption events and one solar-generation event per CSV row.


## Raw / uncleaned dataset notes
The default file `data/energy_uncleaned.csv` is intentionally **not cleaned**.
It includes representative data-quality issues for the project pipeline to detect
and handle downstream:
- Missing values (empty cells).
- Invalid text in numeric columns (`unknown`, `N/A`).
- One exact duplicate row.
- A malformed timestamp (`not-a-date`).
- Physically implausible values (negative irradiance and negative lighting energy).
- An extreme appliance-energy outlier (`99999`).
- Inconsistent whitespace in a numeric value.

These issues are deliberate, not accidental omissions in the project. Keep this raw
file unchanged as the input layer; perform cleaning/validation in a separate downstream
stage so the team can compare raw and cleaned data. The producer currently applies
basic fallback behavior for missing or non-numeric values and does not deduplicate
records; therefore, some raw quality issues are preserved or represented through
fallback values in the emitted events.
