#!/usr/bin/env python3
"""
Stream energy readings from a CSV file to Kafka topic `energy-raw`.

Supports:
- The included demo CSV columns.
- The UCI Appliances Energy Prediction dataset columns:
  `date`, `Appliances`, `lights`, `T_out` (optional).

Each source row is converted into device-level JSON events plus one solar event.
"""
import argparse
import csv
import json
import logging
import math
import random
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

try:
    from kafka import KafkaProducer
except ImportError:
    KafkaProducer = None

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
LOGGER = logging.getLogger("energy-producer")

DEVICE_SHARES = {
    "fridge-01": ("refrigerator", 0.30),
    "ac-01": ("air_conditioner", 0.45),
    "washing-machine-01": ("washing_machine", 0.25),
}

def parse_timestamp(value):
    if not value:
        return datetime.now(timezone.utc).isoformat()
    value = value.strip().replace(" ", "T")
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed.isoformat()
    except ValueError:
        return datetime.now(timezone.utc).isoformat()

def number(row, *names, default=0.0):
    for name in names:
        raw = row.get(name)
        if raw not in (None, ""):
            try:
                return float(raw)
            except (TypeError, ValueError):
                pass
    return float(default)

def make_events(row, row_number):
    """Convert one dataset row into device and solar events."""
    timestamp = parse_timestamp(row.get("timestamp") or row.get("date"))
    # UCI Appliances Energy Prediction values are energy in Wh per 10-minute interval.
    appliance_wh = number(row, "appliances_wh", "Appliances", default=300)
    lights_wh = number(row, "lights_wh", "lights", default=30)
    temp_c = number(row, "outdoor_temp_c", "T_out", default=25)
    hour = datetime.fromisoformat(timestamp).hour

    # Split the household appliance reading into simulated device readings.
    # Convert Wh/10 min to average watts: Wh * 6.
    events = []
    for device_id, (device_type, share) in DEVICE_SHARES.items():
        # Small bounded variation makes the simulated readings less uniform.
        device_energy_wh = max(0.1, appliance_wh * share * random.uniform(0.92, 1.08))
        power_w = device_energy_wh * 6
        voltage_v = random.uniform(220.0, 240.0)
        events.append({
            "event_id": str(uuid.uuid4()),
            "timestamp": timestamp,
            "device_id": device_id,
            "device_type": device_type,
            "metric_type": "consumption",
            "power_w": round(power_w, 2),
            "voltage_v": round(voltage_v, 2),
            "current_a": round(power_w / voltage_v, 3),
            "energy_wh": round(device_energy_wh, 3),
            "outdoor_temp_c": round(temp_c, 2),
            "location": "home-01",
            "source": "uci_or_demo_dataset",
            "row_number": row_number
        })

    # Lights are kept as a separate device event.
    light_energy_wh = max(0.0, lights_wh)
    light_power_w = light_energy_wh * 6
    light_voltage_v = random.uniform(220.0, 240.0)
    events.append({
        "event_id": str(uuid.uuid4()),
        "timestamp": timestamp,
        "device_id": "lights-01",
        "device_type": "lighting",
        "metric_type": "consumption",
        "power_w": round(light_power_w, 2),
        "voltage_v": round(light_voltage_v, 2),
        "current_a": round(light_power_w / light_voltage_v, 3) if light_voltage_v else 0,
        "energy_wh": round(light_energy_wh, 3),
        "outdoor_temp_c": round(temp_c, 2),
        "location": "home-01",
        "source": "uci_or_demo_dataset",
        "row_number": row_number
    })

    # Solar production is simulated from irradiance when available.
    irradiance = number(row, "solar_irradiance_wm2", default=-1)
    if irradiance < 0:
        # Approximate daylight curve for the UCI dataset, which has no solar column.
        daylight = max(0.0, math.sin(math.pi * (hour - 6) / 12)) if 6 <= hour <= 18 else 0.0
        irradiance = 850.0 * daylight

    panel_area_m2 = 12.0
    panel_efficiency = 0.19
    solar_power_w = max(0.0, irradiance * panel_area_m2 * panel_efficiency)
    solar_voltage_v = random.uniform(210.0, 235.0)
    solar_energy_wh = solar_power_w / 6  # energy generated in a 10-minute interval
    events.append({
        "event_id": str(uuid.uuid4()),
        "timestamp": timestamp,
        "device_id": "solar-inverter-01",
        "device_type": "solar_panel",
        "metric_type": "generation",
        "power_w": round(solar_power_w, 2),
        "voltage_v": round(solar_voltage_v, 2),
        "current_a": round(solar_power_w / solar_voltage_v, 3) if solar_voltage_v else 0,
        "energy_wh": round(solar_energy_wh, 3),
        "solar_irradiance_wm2": round(irradiance, 2),
        "location": "home-01",
        "source": "simulated_solar",
        "row_number": row_number
    })
    return events

def main():
    parser = argparse.ArgumentParser(description="Send real-time energy events to Kafka.")
    parser.add_argument("--csv", default="data/energy_uncleaned.csv", help="Input CSV dataset")
    parser.add_argument("--broker", default="localhost:9092", help="Kafka bootstrap server")
    parser.add_argument("--topic", default="energy-raw", help="Kafka topic")
    parser.add_argument("--interval", type=float, default=2.0, help="Delay between dataset rows")
    parser.add_argument("--loop", action="store_true", help="Replay CSV continuously")
    parser.add_argument("--dry-run", action="store_true", help="Print JSON events without Kafka")
    args = parser.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        raise SystemExit(f"CSV file not found: {csv_path}")

    if not args.dry_run and KafkaProducer is None:
        raise SystemExit("kafka-python is missing. Run: pip install -r requirements.txt")

    kafka = None
    if not args.dry_run:
        kafka = KafkaProducer(
            bootstrap_servers=args.broker.split(","),
            value_serializer=lambda value: json.dumps(value).encode("utf-8"),
            key_serializer=lambda value: value.encode("utf-8"),
            acks="all",
            retries=5,
            linger_ms=20,
        )
        LOGGER.info("Connected to Kafka broker %s", args.broker)

    try:
        while True:
            with csv_path.open("r", newline="", encoding="utf-8-sig") as f:
                reader = csv.DictReader(f)
                count = 0
                for count, row in enumerate(reader, start=1):
                    for event in make_events(row, count):
                        if args.dry_run:
                            print(json.dumps(event, ensure_ascii=False))
                        else:
                            kafka.send(args.topic, key=event["device_id"], value=event)
                    if not args.dry_run:
                        kafka.flush(timeout=10)
                    LOGGER.info("Processed dataset row %s", count)
                    time.sleep(max(0.0, args.interval))
            if not args.loop:
                break
    except KeyboardInterrupt:
        LOGGER.info("Stopped by user.")
    finally:
        if kafka is not None:
            kafka.flush(timeout=10)
            kafka.close()

if __name__ == "__main__":
    main()
